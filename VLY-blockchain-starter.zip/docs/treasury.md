# VLY Treasury & Premine Policy

- **Premine**: 1,000,000 VLY at **block #1** to the official treasury address (`vly1...`).
- **Purpose**: DEX liquidity, MM, listings, infra.
- **Controls**: Move to a 2/3 multisig (Squads/Gnosis style).
- **Vesting**: Suggest 10% monthly unlock.
- **Transparency**: Publish treasury address, premine txid, monthly reports.
